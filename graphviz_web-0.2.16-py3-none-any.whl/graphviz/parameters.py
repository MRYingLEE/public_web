# src/graphviz/parameters.py
"""Parameters for the Graphviz interface."""

ENGINES = {'dot', 'neato', 'twopi', 'circo', 'fdp', 'sfdp', 'patchwork', 'osage'}
FORMATS = {'svg', 'dot', 'json', 'xdot'}
RENDERERS = {'svg'}
FORMATTERS = {'svg'}
