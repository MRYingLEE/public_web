# src/graphviz/exceptions.py
"""graphviz exceptions."""

class ExecutableNotFound(RuntimeError):
    """The viz.js module could not be loaded."""

class CalledProcessError(RuntimeError):
    """Rendering failed."""

class RequiredArgumentError(Exception):
    """Required argument missing."""
