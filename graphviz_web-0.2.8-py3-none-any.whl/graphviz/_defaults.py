# src/graphviz/_defaults.py
"""Default values for parameters."""

DEFAULT_ENGINE = 'dot'
DEFAULT_FORMAT = 'svg'
JUPYTER_FORMAT = 'svg'

def set_default_engine(engine):
    """Set the default layout engine for new graphs."""
    global DEFAULT_ENGINE
    if engine not in ENGINES:
        raise ValueError(f'unknown engine: {engine}')
    DEFAULT_ENGINE = engine

def set_default_format(format):
    """Set the default output format for new graphs."""
    global DEFAULT_FORMAT
    if format not in FORMATS:
        raise ValueError(f'unknown format: {format}')
    DEFAULT_FORMAT = format

def set_jupyter_format(format):
    """Set the default format for Jupyter notebook output."""
    global JUPYTER_FORMAT
    if format not in FORMATS:
        raise ValueError(f'unknown format: {format}')
    JUPYTER_FORMAT = format
