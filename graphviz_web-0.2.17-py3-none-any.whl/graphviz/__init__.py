# src/graphviz/__init__.py
"""Assemble DOT source code and render it with viz.js in Pyodide."""

from ._defaults import set_default_engine, set_default_format, set_jupyter_format
from .graphs import Graph, Digraph
from .sources import Source

__version__ = '0.1.0'
__author__ = 'Your Name <your.email@example.com>'
__license__ = 'MIT'

ENGINES = {'dot', 'neato', 'twopi', 'circo', 'fdp', 'sfdp', 'patchwork', 'osage'}
FORMATS = {'svg', 'dot', 'json', 'xdot'}

__all__ = [
    'ENGINES',
    'FORMATS',
    'Graph',
    'Digraph',
    'Source',
    'set_default_engine',
    'set_default_format',
    'set_jupyter_format',
]
