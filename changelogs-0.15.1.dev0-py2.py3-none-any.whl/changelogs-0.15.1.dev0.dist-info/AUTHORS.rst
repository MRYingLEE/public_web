=======
Credits
=======

Development Lead
----------------

* Jannis Gebauer <jay@pyup.io>

Contributors
------------

None yet. Why not be the first?
