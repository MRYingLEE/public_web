def get_urls(releases, **kwargs):
    return {
        'https://raw.githubusercontent.com/jschneier/django-storages/master/CHANGELOG.rst'
    }, set()
