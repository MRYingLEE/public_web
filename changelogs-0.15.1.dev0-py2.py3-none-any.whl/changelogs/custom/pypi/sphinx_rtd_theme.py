def get_urls(*args, **kwargs):
    return {
        'https://raw.githubusercontent.com/rtfd/sphinx_rtd_theme/master/README.rst'
    }, set()
