def get_urls(*args, **kwargs):
    return {
        'https://raw.githubusercontent.com/pallets/jinja/master/CHANGES'
    }, set()
