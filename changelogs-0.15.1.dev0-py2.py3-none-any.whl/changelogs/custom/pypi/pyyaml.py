def get_urls(releases, **kwargs):
    return {"http://svn.pyyaml.org/pyyaml/trunk/CHANGES"}, set()
