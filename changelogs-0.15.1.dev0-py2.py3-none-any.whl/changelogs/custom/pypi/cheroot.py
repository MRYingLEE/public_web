def get_urls(releases, **kwargs):
    return [
        'https://raw.githubusercontent.com/cherrypy/cheroot/master/CHANGES.rst'
    ], set()
