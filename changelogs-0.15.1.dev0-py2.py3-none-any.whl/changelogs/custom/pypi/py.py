def get_urls(releases, **kwargs):
    return ["https://raw.githubusercontent.com/pytest-dev/py/master/CHANGELOG"], []
