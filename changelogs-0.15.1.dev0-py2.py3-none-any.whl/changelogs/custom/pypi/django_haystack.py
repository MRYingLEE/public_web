URL = 'https://raw.githubusercontent.com/django-haystack/django-haystack/master/docs/changelog.rst'


def get_urls(releases, **kwargs):
    return {URL}, set()
