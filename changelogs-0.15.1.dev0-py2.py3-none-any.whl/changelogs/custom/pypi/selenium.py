def get_urls(releases, **kwargs):
    return ["https://raw.githubusercontent.com/SeleniumHQ/selenium/master/py/CHANGES"], []
