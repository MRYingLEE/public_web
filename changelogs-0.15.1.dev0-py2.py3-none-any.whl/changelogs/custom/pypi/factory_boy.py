def get_urls(*args, **kwargs):
    return {
               'https://raw.githubusercontent.com/FactoryBoy/factory_boy/master/docs/changelog.rst'
           }, set()
