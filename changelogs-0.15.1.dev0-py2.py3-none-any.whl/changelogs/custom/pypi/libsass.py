def get_urls(releases, **kwargs):
    return {'https://raw.githubusercontent.com/dahlia/libsass-python/master/docs/changes.rst'}, \
           set()
