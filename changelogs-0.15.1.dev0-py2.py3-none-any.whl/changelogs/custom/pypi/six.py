def get_urls(*args, **kwargs):
    return {'https://raw.githubusercontent.com/benjaminp/six/master/CHANGES'}, set()
