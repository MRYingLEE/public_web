def get_urls(*args, **kwargs):
    return {
        'https://raw.githubusercontent.com/ionelmc/python-lazy-object-proxy/master/CHANGELOG.rst'
    }, set()
