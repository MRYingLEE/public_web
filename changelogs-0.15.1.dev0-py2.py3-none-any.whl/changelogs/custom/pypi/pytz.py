def get_urls(*args, **kwargs):
    return {'https://git.launchpad.net/pytz/plain/src/CHANGES.txt'}, set()
