def get_urls(*args, **kwargs):
    return {
        'http://docutils.sourceforge.net/RELEASE-NOTES.txt'
    }, set()
