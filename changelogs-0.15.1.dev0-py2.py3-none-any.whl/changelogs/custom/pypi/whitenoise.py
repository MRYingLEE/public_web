def get_urls(*args, **kwargs):
    return {
        'https://raw.githubusercontent.com/evansd/whitenoise/master/docs/changelog.rst'
    }, set()
