from IPython.display import SVG, display  # Import necessary modules
from pyodide.ffi import create_proxy, to_js
from js import Viz, global_graphviz_instance, Object
import asyncio
import io
import sys

class Source:
    """Source - Graph source code in dot language."""
    
    def __init__(self, source='', filename=None, directory='', engine='dot', format='svg'):
        self.source = source
        self.filename = filename
        self.directory = directory
        self.engine = engine
        self.format = format
        
    def __str__(self):
        return self.source
        
    def _repr_svg_(self):
        """Return SVG representation of the graph."""
        return  self.pipe(format='svg')
    
    def pipe(self, format='svg', renderer=None, formatter=None):
        """Pipe source through viz.js and return the result as bytes."""
        if format not in ('svg', 'dot', 'json', 'xdot', 'png', 'jpg', 'jpeg', 'pdf'):
            raise ValueError(f'Unknown format: {format}')
            
        # Initialize viz.js instance
        viz = global_graphviz_instance #await instance()
        
        # Create options object
        options = Object.fromEntries(to_js({
            'engine': self.engine,
            'format': format
        }))
        
        try:
            result = viz.render(self.source, options)
            if result.status == 'success':
                return result.output
            else:
                error_msg = '; '.join(err.message for err in result.errors if hasattr(err, 'message'))
                raise RuntimeError(f"Graphviz render error: {error_msg}\n source:\n {self.source}")
        except Exception as e:
            raise RuntimeError(f"Graphviz error: {str(e)}")

class Graph:
    """Graph - Directed or undirected graph."""
    
    def __init__(self, name='G', filename=None, engine='dot',
                graph_attr=None, node_attr=None, edge_attr=None, body=None,
                strict=True, directed=False):
                
        self.name = name
        self.filename = filename
        self.engine = engine
        self.graph_attr = graph_attr or {}
        self.node_attr = node_attr or {}
        self.edge_attr = edge_attr or {}
        self.body = body or []
        self.strict = strict
        self.directed = directed
        
    def edge(self, tail_name, head_name, **attrs):
        """Create edge between two nodes."""
        edge_str = '->' if self.directed else '--'
        attr_list = [f'{k}="{v}"' for k, v in attrs.items()]
        attr_str = f' [{", ".join(attr_list)}]' if attr_list else ''
        self.body.append(f'    "{tail_name}" {edge_str} "{head_name}"{attr_str};')
        
    def node(self, name, **attrs):
        """Create node."""
        attr_list = [f'{k}="{v}"' for k, v in attrs.items()]
        attr_str = f' [{", ".join(attr_list)}]' if attr_list else ''
        self.body.append(f'    "{name}"{attr_str};')
        
    def _attr_str(self, attr_dict):
        """Convert attribute dictionary to dot format."""
        if not attr_dict:
            return ''
        # attr_list = [f'{k}="{v}"' for k, v in attr_dict.items()]
        # Generate the attribute list with specific conditions for the "image" key # TODO: to improve later
        attr_list = [
            f'{k}="{v.replace("/lib/python3.12/site-packages/resources/", "./resources/")}"' if k == "image" else f'{k}="{v}"'
            for k, v in attr_dict.items()
        ]

        return f'     {"; ".join(attr_list)}; '
    
    def source(self):
        """Generate dot source code."""
        graph_type = 'digraph' if self.directed else 'graph'
        strict = 'strict ' if self.strict else ''
        lines = [f'{strict}{graph_type} {self.name} {{']
        
        # Add graph/node/edge attributes
        if self.graph_attr:
            lines.append('    // Graph attributes')
            lines.append('{ '+self._attr_str(self.graph_attr)+' }')
        if self.node_attr:
            lines.append('    // Node attributes')
            lines.append('    node [' + self._attr_str(self.node_attr)+']')
        if self.edge_attr:
            lines.append('    // Edge attributes')
            lines.append('    edge [' + self._attr_str(self.edge_attr)+']')
            
        # Add nodes and edges
        if self.body:
            lines.append('    // Nodes and edges')
            lines.extend(self.body)
            
        lines.append('}')
        return '\n'.join(lines)
    
    def pipe(self, format='svg'):
        """Pipe source through viz.js and return the result."""
        src = Source(self.source(), engine=self.engine)
        return  src.pipe(format=format)
        
    def _repr_svg_(self):
        """Return SVG representation of the graph."""
        return  self.pipe(format='svg')

    def render(self, format='svg', view=None, quiet=True):
        """Pipe source through viz.js and return the result."""
        src = Source(self.source(), engine=self.engine)
        return  src.pipe(format=format)   


class Digraph(Graph):
    """Directed graph."""
    
    def __init__(self, name='G', filename=None, engine='dot',
                graph_attr=None, node_attr=None, edge_attr=None, body=None,
                strict=True):
        super().__init__(name=name, filename=filename, engine=engine,
                        graph_attr=graph_attr, node_attr=node_attr,
                        edge_attr=edge_attr, body=body,
                        strict=strict, directed=True)