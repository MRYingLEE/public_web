# src/graphviz/sources.py
"""Graphviz Source Code Classes."""

from js import Viz, instance, Object
from pyodide.ffi import create_proxy, to_js

class Source:
    """Source - Graph source code in dot language."""
    
    def __init__(self, source='', filename=None, directory='', engine='dot', format='svg'):
        self.source = source
        self.filename = filename
        self.directory = directory
        self.engine = engine
        self.format = format
        
    def __str__(self):
        return self.source
        
    async def _repr_svg_(self):
        """Return SVG representation of the graph."""
        return await self.pipe(format='svg')
    
    async def pipe(self, format='svg', renderer=None, formatter=None):
        """Pipe source through viz.js and return the result as bytes."""
        if format not in ('svg', 'dot', 'json', 'xdot'):
            raise ValueError(f'Unknown format: {format}')
            
        # Initialize viz.js instance
        viz = await instance()
        
        # Create options object
        options = Object.fromEntries(to_js({
            'engine': self.engine,
            'format': format
        }))
        
        try:
            result = viz.render(self.source, options)
            if result.status == 'success':
                return result.output
            else:
                error_msg = '; '.join(err.message for err in result.errors if hasattr(err, 'message'))
                raise RuntimeError(f"Graphviz render error: {error_msg}")
        except Exception as e:
            raise RuntimeError(f"Graphviz error: {str(e)}")
